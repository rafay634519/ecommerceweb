package com.shopme.common.entity;

public enum AuthenticationType {
	DATABASE, GOOGLE, FACEBOOK
}
