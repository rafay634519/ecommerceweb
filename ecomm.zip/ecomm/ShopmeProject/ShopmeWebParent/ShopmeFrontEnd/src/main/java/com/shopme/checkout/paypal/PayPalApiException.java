package com.shopme.checkout.paypal;

public class PayPalApiException extends Exception {

	public PayPalApiException(String message) {
		super(message);
	}

}
