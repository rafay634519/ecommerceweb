package com.shopme.shoppingcart;

public class ShoppingCartException extends Exception {

	public ShoppingCartException(String message) {
		super(message);
	}

}
