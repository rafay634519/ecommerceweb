package com.shopme.admin.shippingrate;

public class ShippingRateNotFoundException extends Exception {

	public ShippingRateNotFoundException(String message) {
		super(message);
	}

}
